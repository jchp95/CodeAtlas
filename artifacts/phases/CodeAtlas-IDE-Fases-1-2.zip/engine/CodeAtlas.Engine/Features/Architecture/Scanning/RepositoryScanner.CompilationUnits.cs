using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;

/// <summary>Source files, parsed trees and the best-effort Roslyn compilation for one .csproj.</summary>
sealed record ProjectCompilationUnit(string[] SourceFiles, SyntaxTree[] SyntaxTrees, CSharpCompilation Compilation);

/// <summary>A .NET project ready for analysis, with the metadata needed to key caches and name findings.</summary>
sealed record LoadedDotnetProject(
    string ProjectFile,
    string RelativeProjectFile,
    string Name,
    ProjectCompilationUnit Unit,
    string[] Warnings,
    string ReferenceFingerprint);

sealed partial class RepositoryScanner
{
    /// <summary>Enumerates .csproj files using the same exclusion rules as the architecture scan.</summary>
    internal IEnumerable<string> FindDotnetProjectFiles() => EnumerateFiles(root, "*.csproj").OrderBy(p => p, StringComparer.Ordinal);

    internal string ToRelativePath(string path) => Relative(path);

    /// <summary>
    /// Builds the same compilation the architecture scan uses, so analyzer diagnostics and architecture
    /// evidence are derived from one semantic model instead of two diverging ones.
    /// </summary>
    internal LoadedDotnetProject LoadDotnetProject(string projectFile)
    {
        var warnings = new List<string>();
        var relative = Relative(projectFile);
        var name = Path.GetFileNameWithoutExtension(projectFile);
        var framework = DetectTargetFramework(SafeRead(projectFile));
        var unit = CreateProjectCompilation(projectFile, name, framework, relative, warnings);
        return new LoadedDotnetProject(projectFile, relative, name, unit, warnings.ToArray(), FingerprintReferences(projectFile));
    }

    // Package restore output changes the semantic model (resolved symbols), so it is part of the cache key.
    private static string FingerprintReferences(string projectFile)
    {
        var assets = Path.Combine(Path.GetDirectoryName(projectFile)!, "obj", "project.assets.json");
        try
        {
            var info = new FileInfo(assets);
            return info.Exists ? $"{info.Length}:{info.LastWriteTimeUtc.Ticks}" : "no-assets";
        }
        catch { return "no-assets"; }
    }
}
